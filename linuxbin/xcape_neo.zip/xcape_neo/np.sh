#/bin/sh bash 

xmodmap ./neo2015.neo-plain.xmodmap
