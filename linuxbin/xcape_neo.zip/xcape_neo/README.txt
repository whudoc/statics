

	 #    #   ####     ##    #####   ######
	  #  #   #    #   #  #   #    #  #
	   ##    #       #    #  #    #  #####
	   ##    #       ######  #####   #
	  #  #   #    #  #    #  #       #
	 #    #   ####   #    #  #       ######


* We need xcape to assist NEO-extended qwerty, dvp, dvpe
* Copied from: https://github.com/alols/xcape


How to install
==============

1. `sudo apt-get install libxtst-dev` (https://packages.debian.org/zh-cn/sid/libdevel/libxtst-dev)